package com.example.equipos

class BaseJugadores {
    companion object{
        val arregloJugadores = arrayListOf<Jugador>()
        init {

        }

    }

}